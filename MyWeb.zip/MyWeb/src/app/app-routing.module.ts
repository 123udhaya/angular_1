import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './main/main.component';
import { Dialog1Component } from './dialog1/dialog1.component';
const routes: Routes = [
   {
    path: 'main',
    component:  Dialog1Component
  }, {
    path: 'dialog',
    component: Dialog1Component
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
