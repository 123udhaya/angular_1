import { BrowserModule } from '@angular/platform-browser';
import { NgModule,Component, Input } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';  
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Dialog1Component } from './dialog1/dialog1.component';
import { MainComponent } from './main/main.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDialogModule} from "@angular/material";
import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomMaterialModule } from './main/main.module';
import {MatDividerModule} from '@angular/material'
import {MatNativeDateModule,MatIconModule,MatButtonModule,MatCheckboxModule, MatToolbarModule, MatCardModule,MatFormFieldModule,MatInputModule,MatRadioModule,MatListModule} from  '@angular/material';
import { BsDropdownModule} from 'ngx-bootstrap/dropdown';
import { AlertModule } from 'ngx-bootstrap';
import {MatDatepickerModule} from  '@angular/material/datepicker';
import { MatDialog, MatDialogConfig,MatDialogRef} from "@angular/material";
import { DialogRegComponent } from './dialog-reg/dialog-reg.component';
import {MatSelectModule} from '@angular/material/select';
import {MatSidenavModule} from '@angular/material'
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { AnimateOnScrollModule } from 'ng2-animate-on-scroll';
@NgModule({
  declarations: [
    AppComponent,
    Dialog1Component,
    MainComponent,
    DialogRegComponent
    
  ],
  imports: [
    // FormGroup,
    AnimateOnScrollModule,
    FontAwesomeModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatDialogModule,
    FormsModule,
    CustomMaterialModule,
    ReactiveFormsModule,
    MatDividerModule,
    MatListModule,
    NgbModule,
    BsDropdownModule,
    AlertModule,
    MatSelectModule,
    MatSidenavModule,
    MatToolbarModule
   ],  
  providers: [],
  bootstrap: [AppComponent],
  entryComponents:[Dialog1Component, DialogRegComponent]
})
export class AppModule { }
