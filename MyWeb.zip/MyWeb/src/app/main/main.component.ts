import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig,MatDialogRef} from "@angular/material";
import { Dialog1Component } from '../dialog1/dialog1.component';
import { DialogRegComponent } from '../dialog-reg/dialog-reg.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';  
import {MatDialogModule} from '@angular/material/dialog';
import {MatSidenavModule,MatToolbarModule} from '@angular/material';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NgModule } from '@angular/core';
import {FormGroup} from '@angular/forms';
import * as AOS from "aos";
@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  opened:false;
  uname:string="";
  isDisabled:boolean=true;
  isDis:boolean=false;
  constructor(private dialog:MatDialog,config: NgbCarouselConfig) {
    config.interval = 10;  
    config.wrap = true;  
    config.keyboard = false;  
    config.pauseOnHover = false;  
  }  
  ngOnInit(){
  AOS.init({offset:120,
  delay:0,
  easing:'ease',
  duration:1000
});
  } 
onCreate()
{
    const dialogConfig=new MatDialogConfig();
    dialogConfig.disableClose=true;
    dialogConfig.autoFocus=true;
    this.dialog.open(Dialog1Component,dialogConfig);
}
onRegister()
{
    const dialogConfig=new MatDialogConfig();
    dialogConfig.disableClose=true;
    dialogConfig.autoFocus=true;
    this.dialog.open(DialogRegComponent,dialogConfig);
}
fun()
{
  this.uname=" ";
  this.isDisabled=true;
}
onUpdate(event:Event)
{
  this.isDisabled=false;
}

public Roles=["development","officer","manager"];
images=[
"../assets/p5.jpg",
"../assets/d12.jpg",
"../assets/d11.jpg"
];
taxi=[
  "This is the image of NEWYORK",
  "This is the image of US",
  "This is the image of CALIFORNIA"
]
}
