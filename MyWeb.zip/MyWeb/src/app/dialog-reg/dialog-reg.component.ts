import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig,MatDialogRef} from "@angular/material";
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';  
import {MatDialogModule} from '@angular/material/dialog';

import { Router } from '@angular/router'; 
import {MatSelectModule} from '@angular/material/select';

@Component({
  selector: 'app-dialog-reg',
  templateUrl: './dialog-reg.component.html',
  styleUrls: ['./dialog-reg.component.css']
})
export class DialogRegComponent implements OnInit {
public Roles=["development","officer","manager"];
  constructor(public dialog1Ref: MatDialog,private router:Router) { }

  ngOnInit() {
  }
 Register()  {
    this.router.navigate(['/main']);
    this.dialog1Ref.closeAll();
  }

}
