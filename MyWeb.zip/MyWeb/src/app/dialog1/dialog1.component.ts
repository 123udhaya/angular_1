import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig,MatDialogRef} from "@angular/material";
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';  
import {MatDialogModule} from '@angular/material/dialog';
/*import { RouterModule, Routes} from '@angular/router';*/
import { Router } from '@angular/router'; 

@Component({
  selector: 'app-dialog1',
  templateUrl: './dialog1.component.html',
  styleUrls: ['./dialog1.component.css']
})
export class Dialog1Component implements OnInit {
    username:string;
  password:string;
  constructor( public dialog1Ref: MatDialog,private router:Router) {

   }
  
  close() {
    this.dialog1Ref.closeAll();
  }
  
  ngOnInit() {
  }
  login()  {
    
    if(this.username == 'admin' && this.password == 'admin')
    {
    this.router.navigate(['/main']);
    this.dialog1Ref.closeAll();
    }else {
      alert("Invalid credentials");
    }
  }
}
