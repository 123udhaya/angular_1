import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-server',
  templateUrl: './server.component.html',
  styleUrls: ['./server.component.css']
})
export class ServerComponent implements OnInit {
  messages = ['item1','item2','item3','item4'];
  serverWorks=false;
  constructor() { 
    setTimeout(()=>{
      this.serverWorks=true;
    },2000);
  }
  
  ngOnInit() {
  }

}
