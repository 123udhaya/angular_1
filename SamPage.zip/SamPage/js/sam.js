
    $(document).ready(function () {

        $("#home").click(function () {
          $(document).attr("title",  "Two Bytes | Home");
        });

        $("#about").click(function () {
          $(document).attr("title",  "Two Bytes | About");
        });

        $("#jobs").click(function () {
          $(document).attr("title",  "Two Bytes | Jobs");
        });

        $("#clients").click(function () {
          $(document).attr("title",  "Two Bytes | Clients");
        });

        $("#employers").click(function () {
          $(document).attr("title",  "Two Bytes | Employers");
        });

        $("#contact").click(function () {
          $(document).attr("title",  "Two Bytes | Contact");
        });
      });

      function checkEmail() {

        var email = document.getElementById('email');
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!filter.test(email.value)) {
          document.getElementById('error-val1').innerHTML = '*Please provide a valid email address';
          email.focus();
          return false;
        }

      }

      function validate_form() {
        //var str=" ";
        var c = 0;
        var r = 0;
        valid = true;
        if ($('input[type=checkbox]:checked').length == 0) {
          //document.getElementById('error-val2').innerHTML = '*Please select atleast one checkbox';
          //str+="ERROR! Please select at least one checkbox ";
          c++;
          valid = false;
        }
        var e = document.getElementById("select");
        var strUser = e.options[e.selectedIndex].value;
        var strUser1 = e.options[e.selectedIndex].text;
        if (strUser == 0) {
          //document.getElementById('error-val1').innerHTML = '*Please select a location';
          //str+="and Please select a location";
          r++;
        }

        if (c == 1 && r == 1) {
          document.getElementById('error-val2').innerHTML = '*Please select atleast one checkbox and ';
          document.getElementById('error-val3').innerHTML = 'Please select a location';
          return false;
        }
        else if (r == 1 && c == 0) {
          document.getElementById('error-val3').innerHTML = '*Please select a location';
          return false;
        }

        else if (c == 1 && r == 0) {
          document.getElementById('error-val2').innerHTML = '*Please select atleast one checkbox';
          return false;
        }
        else {

        }
        //alert(str).appendTo(document.body);

        return valid;
      }

      function changeCheckbox(event) {
        let item = document.getElementById('defaultInline1');
        switch (item.getAttribute('aria-checked')) {
          case "true":
            item.setAttribute('aria-checked', "false");
            break;
          case "false":
            item.setAttribute('aria-checked', "true");
            break;
        }
      }
      function changeCheckbox1(event) {
        let item = document.getElementById('defaultInline2');
        switch (item.getAttribute('aria-checked')) {
          case "true":
            item.setAttribute('aria-checked', "false");
            break;
          case "false":
            item.setAttribute('aria-checked', "true");
            break; z
        }
      } 


         var i = 0;
                                                    var readmore = document.getElementById('para2');
                                                    var dots = document.getElementById('dots');
                                                    var btn = document.getElementById('read');
                                                    function read() {
                                                      if (i == 0) {
                                                        readmore.style.display = "block";
                                                        dots.style.display = "none";
                                                        btn.innerHTML = "Read less";
                                                        i = 1;
                                                      }
                                                      else {
                                                        readmore.style.display = "none";
                                                        dots.style.display = "block";
                                                        btn.innerHTML = "Read more about us";
                                                        i = 0;
                                                      }
                                                    }
    