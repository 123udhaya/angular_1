import { Component } from '@angular/core';
declare function checkEmail(): any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent{
  /*shaObj: any;
  hash: string;
  constructor()
  {
   /* this.shaObj=new jsSHA("SHA-512","TEXT");
    this.shaObj.Update("this s a test"); 
    this.hash=this.shaObj.getHash("HEX");
}*/
ngOnInit()
{
  
}
onCreate()
{
checkEmail();
}
  title = 'SamPage';
}
