import {Component} from '@angular/core';
import {trigger} from '@angular/animations';
import { NgModule } from '@angular/core';
import {state} from '@angular/animations';
import {style} from '@angular/animations';
import {transition,stagger,query} from '@angular/animations';
import {animate} from '@angular/animations';
import {keyframes} from '@angular/animations';
import {group} from '@angular/animations';
import { ScrollEventModule } from 'ngx-scroll-event';
import * as AOS from "aos";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  animations:[
    trigger('text',[
      transition(':enter',[
        style({transform:'translateX(-100%)'}),
        animate('2s',keyframes([
          style({opacity:0, transform:'translateX(-100%)', offset:0}),
          style({opacity:1, transform:'translate(10px,0px)',offset:0.1}),
          style({opacity:1, transform:'translate(40px,50px)', offset:0.2}),
         style({opacity:1, transform:'translate(80px,-50px)', offset:0.3}),
          style({opacity:1, transform:'translate(120px,50px)', offset:0.4}),
          style({opacity:1, transform:'translate(160px,-50px)', offset:0.5}),
          style({opacity:1, transform:'translate(200px,50px)', offset:0.6}),
          style({opacity:1, transform:'translate(240px,-50px)', offset:0.7}),
          style({opacity:1, transform:'translate(280px,50px)', offset:0.8}),
          style({opacity:1, transform:'translate(320px,-50px)', offset:0.9}),
          style({opacity:1, transform:'translate(0)', offset:1})
        ])
        )
        ]),
      transition(':leave',[
                animate(3000,keyframes([
          style({opacity:1, transform:'translateX(0)', offset:0}),
          style({opacity:1, transform:'translateX(-15px)', offset:0.3 }),
          style({opacity:0, transform:'translateX(100%)', offset:1})
        ])
        )
    ])])
    ,
    trigger('lightsOnOff',[
      state('off',style({
        backgroundColor:'black'
      })),
      state('on',style({
        backgroundColor:'white'
      })),
      transition('off => on',[animate('2s',style({transform:'rotate(90deg)'}))]),
      transition('on => off',[animate('2s',style({transform:'rotate(90deg)'}))])
    ]),
    trigger('lightsOnOff1',[
      state('off',style({
        backgroundColor:'black'
      })),
      state('on',style({
        backgroundColor:'white'
      })),
      transition('off => on',[animate('2s',style({transform:'rotate(90deg)'}))]),
      transition('on => off',[animate('2s',style({transform:'rotate(90deg)'}))])
    ]), 
    trigger('lightsOnOff2',[
      state('off',style({
        backgroundColor:'black'
      })),
      state('on',style({
        backgroundColor:'white'
      })),
      transition('off => on',[animate('2s',style({transform:'rotate(90deg)'}))]),
      transition('on => off',[animate('2s',style({transform:'rotate(90deg)'}))])
    ]),
    trigger('lightsOnOff3',[
      state('off',style({
        backgroundColor:'black'
      })),
      state('on',style({
        backgroundColor:'white'
      })),
      transition('off => on',[animate('2s',style({transform:'rotate(90deg)'}))]),
      transition('on => off',[animate('2s',style({transform:'rotate(90deg)'}))])
    ]),
     trigger('lightsOnOff4',[
      state('off',style({
        backgroundColor:'black'
      })),
      state('on',style({
        backgroundColor:'white'
      })),
      transition('off => on',[animate('2s',style({transform:'rotate(90deg)'}))]),
      transition('on => off',[animate('2s',style({transform:'rotate(90deg)'}))])
    ]),
    trigger('lights1',[
      state('off',style({
        backgroundColor:'skyblue',
        height:'*'
      })),
      state('on',style({
        backgroundColor:'skyblue',
        height:0
      })),
       transition('off => on',[group([
        animate('2s',style({
          transform:'rotate(-90deg)',
          height:'*'
        }))
    ])]),
    transition('on => off',[group([
        animate('2s',style({
          transform:'rotate(-90deg)',
          opacity:0
        }))
    ])])
    ]),
    trigger('lights2',[
      state('off',style({
        backgroundColor:'skyblue',
        height:0
      })),
      state('on',style({
        backgroundColor:'skyblue',
        height:'*'
      })),
      transition('off => on',[group([
        animate('2s',style({
          transform:'rotate(-90deg)',
          height:'*'
        }))
            ])]),
    transition('on => off',[group([
        animate('2s',style({
          transform:'rotate(-90deg)',
          opacity:0

        }))
    ])])
    ]),
    trigger('lights3',[
      state('off',style({
        backgroundColor:'skyblue',
        height:0
      })),
      state('on',style({
        backgroundColor:'skyblue',
        height:'*'
      })),
       transition('off => on',[group([
        animate('2s',style({
          transform:'rotate(-90deg)',
          height:'*'
        }))
    ])]),
    transition('on => off',[group([
        animate('2s',style({
          transform:'rotate(-90deg)',
          opacity:0

        }))
    ])])
    ]),
    trigger('lights4',[
      state('off',style({
        backgroundColor:'skyblue',
        height:'*'
      })),
      state('on',style({
        backgroundColor:'skyblue',
        height:0
      })),
      transition('off => on',[group([
        animate('2s',style({
          transform:'rotate(-90deg)',
          height:'*'
        }))
    ])]),
    transition('on => off',[group([
        animate('2s',style({
          transform:'rotate(-90deg)',
          opacity:0
        }))
    ])])
    ]),
    trigger('scrollAnimation', [
      state('show', style({
        opacity: 1,
        transform: "translateX(0)"
      })),
      state('hide',   style({
        opacity: 0,
        transform: "translateX(-100%)"
      })),
      transition('show => hide', animate('700ms ease-out')),
      transition('hide => show', animate('700ms ease-in'))
    ]),


    trigger('listAnimation', [
  transition('* => 3', [
    query(':enter', [
      style({ opacity: 0, transform: 'translateY(-100px)' }),
      stagger(50, [
        animate('1000ms ease-out', style({ opacity: 1, transform: 'none' })),
      ])
    ])
  ])
    ])
    
  ]
})
export class AppComponent{
  ngOnInit(){
    AOS.init({offset:120,
  delay:0,
  easing:'ease',
  duration:1200
});
  } 
  items=[
    "../assets/d11.jpg",
    "../assets/d11.jpg",
    "../assets/d11.jpg"
  ];
/*state = 'hide';   
 title = 'my portal application';
  roomState: String="off";
  rm1State: String="off";
  room1State: String="off";
  rm2State: String="off";
  room2State: String="off";
  rm3State: String="off";
  room3State: String="off";
  rm4State: String="off";
  room4State: String="off";
  h1: String="off";
  show:boolean=true;
  toggleit()
  {
    
    this.roomState=(this.roomState=="off")?"on":"off";
    this.rm1State=(this.rm1State=="off")?"on":"off";
    this.room1State=(this.room1State=="off")?"on":"off";
    this.rm2State=(this.rm2State=="off")?"on":"off";
    this.room2State=(this.room2State=="off")?"on":"off";
    this.rm3State=(this.rm3State=="off")?"on":"off";
    this.room3State=(this.room3State=="off")?"on":"off";
    this.rm4State=(this.rm4State=="off")?"on":"off";
    this.room4State=(this.room4State=="off")?"on":"off";
    this.h1=(this.h1=="noHeight")?"fullHeight":"noHeight";
    this.show=this.show?false:true;
  }
  */
  
  

  

}
