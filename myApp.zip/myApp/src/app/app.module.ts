import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
import { NgDirComponent } from './ng-dir/ng-dir.component';
import { Component } from '@angular/core';
import { OnInit, ViewChild, ElementRef, EventEmitter, Output } from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition,
  stagger,
  query
} from '@angular/animations';

      

@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    NgDirComponent
  ],
  imports: [
    
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    AppRoutingModule
  
     ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
