import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-dir',
  templateUrl: './ng-dir.component.html',
  styleUrls: ['./ng-dir.component.scss']
})
export class NgDirComponent implements OnInit {
public display1=true;
public color='blue';
public colors=['red','green','yellow'];
public cone=true;
public ctwo=true;
public one='40px';
public two='italic';
  constructor() { }

  ngOnInit() {
  }
toggle()
{
  this.cone=!this.cone;
  this.ctwo=!this.ctwo;
}
}
