import { Component, OnInit } from '@angular/core';
import { EventEmitter } from '@angular/core';
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss'],
  inputs:['parentdata'],
  outputs:['childevent']
})
export class TestComponent implements OnInit {
  public name;
 /*date=new Date();
  public parentdata:string;
public name="udhaya nilani";
public name1;
public myid="testid";
public titleStyles={
  color: "green",
  fontSize:"10px",
}
childevent=new EventEmitter<String>();*/
  constructor() { }

  ngOnInit() {
  }

/*method1()
{
  return "hello ***"+this.name;
}
myfunc(ptr)
{
  console.log(ptr);
}
/*onChange(value:string)
{
  this.childevent.emit(value);
}
onSubmit(value:any)
{
  console.log(value);
}*/
employees=[
  {"id":1,"name":"udhaya"},
  {"id":2,"name":"sugirtha"},
  {"id":3,"name":"prabha"}
]
}
